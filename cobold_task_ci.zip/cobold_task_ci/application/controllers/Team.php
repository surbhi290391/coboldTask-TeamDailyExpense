<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Team extends CI_Controller
{
	//Constructor
	public function __construct()
	{
		parent::__construct();
		$this->load->model('teammodel', '', TRUE);
		$this->team_model = new TeamModel();
	}

	/* Function Name: index()
		*  Function Type: Declarative
		*  Function Parameters: No param require
		*  Function Description: Function to display all team members
		*  Function Return: TRUE|FALSE
    */
	public function index()
	{
		$data['title'] = "Laravel Assignment - Team";
		$data['description'] = "";
		$data['keyword'] = "";
		$data['team_list'] = $this->team_model->fetchTeamList();
		if ($data['team_list'] && count($data['team_list'])) {
			$team = $data['team_list'];
			$ti = 0;
			foreach ($team as $t) {
				$t = $this->team_model->fetchLastExpenseDate($t->id);
				if($t){
					$team[$ti]->lastExpenseDate = $t->lastExpenseDate;
				}else{
					$team[$ti]->lastExpenseDate = "";
				}
				$ti++;
			}
			$data['team_list'] = $team;
		}
		$data['page'] = $this->load->view('site/team', $data, TRUE);
		$this->load->view('layouts/main', $data, FALSE);
	}

	/* Function Name: addTeam()
		*  Function Type: Declarative
		*  Function Parameters: POST Param
		*  Function Description: Function to add team member
		*  Function Return: TRUE|FALSE
    */
	public function addTeam()
	{
		$this->form_validation->set_rules('firstName', 'First Name', 'trim|required');
		$this->form_validation->set_rules('lastName', 'Last Name', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[tbl_team.email]');
		if ($this->form_validation->run() == false) {
			$data['title'] = "Laravel Assignment - Team";
			$data['description'] = "";
			$data['keyword'] = "";
			$data['team_list'] = $this->team_model->fetchTeamList();
			$data['page'] = $this->load->view('site/team', $data, TRUE);
			$this->load->view('layouts/main', $data, FALSE);
		} else {
			$data['firstName'] = $this->input->post('firstName', TRUE);
			$data['lastName'] = $this->input->post('lastName', TRUE);
			$data['email'] = $this->input->post('email', TRUE);
			$insertid = $this->team_model->addTeam($data);
			if ($insertid > 0) {
				$this->session->set_flashdata("success", "Team member added successfully.");
				redirect('Team');
			} else {
				$this->session->set_flashdata("error", "Error while adding.");
				redirect('Team');
			}
		}
	}

	/* Function Name: updateTeam()
		*  Function Type: Declarative
		*  Function Parameters: POST Param
		*  Function Description: Function to update team member
		*  Function Return: TRUE|FALSE
    */
	public function updateTeam()
	{
		$this->form_validation->set_rules('firstName', 'First Name', 'trim|required');
		$this->form_validation->set_rules('lastName', 'Last Name', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		if ($this->form_validation->run() == false) {
			$data['title'] = "Laravel Assignment - Team";
			$data['description'] = "";
			$data['keyword'] = "";
			$data['team_list'] = $this->team_model->fetchTeamList();
			$data['page'] = $this->load->view('site/team', $data, TRUE);
			$this->load->view('layouts/main', $data, FALSE);
		} else {
			$data['firstName'] = $this->input->post('firstName', TRUE);
			$data['lastName'] = $this->input->post('lastName', TRUE);
			$data['email'] = $this->input->post('email', TRUE);
			$id = $this->input->post('userid', TRUE);
			$res = $this->team_model->updateTeam($data, $id);
			if ($res)
				$this->session->set_flashdata('success', 'Updated successfully !!');
			else
				$this->session->set_flashdata('error', 'Unable to update! something went wrong !!');
			redirect('Team');
		}
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	//Constructor
	public function __construct(){
        parent::__construct();   
		$this->load->model('homemodel','',TRUE);
		$this->home_model = new HomeModel(); 
		$this->load->model('teammodel','',TRUE);
		$this->team_model = new TeamModel(); 
    }

	/* Function Name: index()
		*  Function Type: Declarative
		*  Function Parameters: No param require
		*  Function Description: Function to display all expenses summary
		*  Function Return: -
    */
	public function index()
	{
	   	$data['title'] = "Cobold Digital - Home";
        $data['description'] = "";
        $data['keyword'] = "";
		$data['transactionDetails'] = $this->home_model->fetchTeamTransaction();
		$data['totalExpense'] = $this->team_model->fetchTotalExpense();
		$data['highestPaid'] = $this->home_model->highestPaid();
		$data['teamList'] = $this->team_model->fetchTeamList();
		$data['teamMateCounter'] = $this->home_model->fetchTeamMateCounter();
		$data['page'] = $this->load->view('site/home',$data,TRUE);        
        $this->load->view('layouts/main', $data, FALSE);
	}
}

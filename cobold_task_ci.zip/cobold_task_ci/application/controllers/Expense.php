<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Expense extends CI_Controller
{
	//Constructor
	public function __construct()
	{
		parent::__construct();
		$this->load->model('expensemodel', '', TRUE);
		$this->expense_model = new ExpenseModel();
		$this->load->model('teammodel', '', TRUE);
		$this->team_model = new TeamModel();
	}

	/* Function Name: index()
	*  Function Type: Declarative
	*  Function Parameters: No param require
	*  Function Description: Function to display all expenses summary
	*  Function Return: -
    */
	public function index()
	{
		$data['title'] = "Cobold Digital - Expense";
		$data['description'] = "";
		$data['keyword'] = "";
		$data['expense_list'] = $this->expense_model->fetchExpenseWithUser();
		$data['team_list'] = $this->team_model->fetchTeamList();
		$data['page'] = $this->load->view('site/expense', $data, TRUE);
		$this->load->view('layouts/main', $data, FALSE);
	}

	/* Function Name: addExpenses()
		*  Function Type: Declarative
		*  Function Parameters: POST Param
		*  Function Description: Function to add expense of member
		*  Function Return: TRUE|FALSE
    */
	public function addExpenses()
	{
		$this->form_validation->set_rules('userId', 'User', 'trim|required');
		$this->form_validation->set_rules('expenseDate', 'Expense Date', 'trim|required');
		$this->form_validation->set_rules('expenseAmount', 'Expense Amount', 'trim|required');
		if ($this->form_validation->run() == false) {
			$data['title'] = "Laravel Assignment - Expense";
			$data['description'] = "";
			$data['keyword'] = "";
			$data['expense_list'] = $this->expense_model->fetchExpenseWithUser();
			$data['team_list'] = $this->team_model->fetchTeamList();
			$data['page'] = $this->load->view('site/expense', $data, TRUE);
			$this->load->view('layouts/main', $data, FALSE);
		} else {
			$data['userId'] = $this->input->post('userId', TRUE);
			$data['expenseDate'] = $this->input->post('expenseDate', TRUE);
			$data['expenseAmount'] = $this->input->post('expenseAmount', TRUE);
			//Check if expense date should greater then user's registered date
			$expenseCanAdd = $this->team_model->fetchMemberRegisteredDate($data['expenseDate']);
			if ($expenseCanAdd->teamCount > 0) {
				//1. Insert record in expense table
				$insertid = $this->expense_model->addExpense($data);
				$totalExpenseAmount = 0;
				if ($insertid > 0) {
					//2. Update new expense added with respect to user:
					$updateExpense = $this->team_model->updateExpensesOfMember(array(
						"expenseAmount" => $data['expenseAmount'],
						"userId" => $data['userId']
					));
					if ($updateExpense) {
						//3. Fetch total sum of expense from team table
						$totalExpense = $this->team_model->fetchTotalExpense();
						if ($totalExpense) {
							$totalExpenseAmount = $totalExpense->totalExpense;
							//4.Divide total expense with number of team mate
							$amountToPayPerMember = $totalExpenseAmount / ($totalExpense->totalTeamMember);
							$updateAmountToBePaid = $this->team_model->updateAmountToPay(array(
								"amountToPayPerMember" => $amountToPayPerMember
							));
							if ($updateAmountToBePaid) {
								//5. Calculate credit/debit record per user:
								//5.1 Fetch all team members
								$allTeamMembers = $this->team_model->fetchTeamList();
								//5.2 Filter all credit and debit user's
								$creditUsers = array();
								$debitUsers = array();
								foreach ($allTeamMembers as $team) {
									if ($team->balanceAmount > 0) {
										array_push($creditUsers, array(
											"id" => $team->id,
											"name" => $team->firstName . ' ' . $team->lastName,
											"balAmount" => $team->balanceAmount,
											"creditRecord" => array(),
											"creditMsg" => ""
										));
									} else {
										array_push($debitUsers, array(
											"id" => $team->id,
											"name" => $team->firstName . ' ' . $team->lastName,
											"balAmount" => $team->balanceAmount,
											"debitRecord" => array(),
											"debitMsg" => ""
										));
									}
								}
								//CREDIT USER LOOP
								for ($ic = 0; $ic < count($creditUsers); $ic++) {
									$balanceAmountCredit = $creditUsers[$ic]['balAmount'];
									//DEBIT USER LOOP
									for ($id = 0; $id < count($debitUsers); $id++) {
										$balanceAmountDebit = $debitUsers[$id]['balAmount'];
										if ($balanceAmountCredit > 0 && abs($balanceAmountDebit) > 0) {
											//a. if credit user's bal amount greater then debit user's amount then deduct & end loop: i.e. 200 > 100
											if ($balanceAmountCredit > abs($balanceAmountDebit)) {
												$balanceAmountCredit = $balanceAmountCredit - abs($balanceAmountDebit);
												array_push($creditUsers[$ic]['creditRecord'], array(
													$debitUsers[$id]['id'] => abs($balanceAmountDebit)
												));
												$creditUsers[$ic]['creditMsg'] = $creditUsers[$ic]['creditMsg'] . ' ' . $debitUsers[$id]['name'] . ' will pay ' . $creditUsers[$ic]['name'] . ' Rs. ' . abs($balanceAmountDebit) . ';';
												array_push($debitUsers[$id]['debitRecord'], array(
													$creditUsers[$ic]['id'] => abs($balanceAmountDebit)
												));
												$debitUsers[$id]['debitMsg'] = $debitUsers[$id]['debitMsg'] . ' ' . $creditUsers[$ic]['name'] . ' will receive Rs. ' . abs($balanceAmountDebit) . ' from ' . $debitUsers[$id]['name'] . ';';
												$debitUsers[$id]['balAmount'] = 0;
											}
											//b. if credit user's bal amount less then debit user's amount then deduct. i.e 100<200
											else if ($balanceAmountCredit < abs($balanceAmountDebit)) {
												$debitUsers[$id]['balAmount'] = $balanceAmountCredit - abs($balanceAmountDebit); // 100-200=-100
												array_push($creditUsers[$ic]['creditRecord'], array(
													$debitUsers[$id]['id'] => $balanceAmountCredit
												));
												$creditUsers[$ic]['creditMsg'] = $creditUsers[$ic]['creditMsg'] . ' ' . $debitUsers[$id]['name'] . ' will pay ' . $creditUsers[$ic]['name'] . ' Rs. ' . abs($balanceAmountDebit) . ';';
												array_push($debitUsers[$id]['debitRecord'], array(
													$creditUsers[$ic]['id'] => $balanceAmountCredit
												));
												$debitUsers[$id]['debitMsg'] = $debitUsers[$id]['debitMsg'] . ' ' . $creditUsers[$ic]['name'] . ' will receive Rs. ' . abs($balanceAmountDebit) . ' from ' . $debitUsers[$id]['name'] . ';';
												$balanceAmountCredit = 0;
												$creditUsers[$ic]['balAmount'] = 0;
											}
											//c. if credit user's bal amount equal to debit user's amount then deduct & end loop
											else if ($balanceAmountCredit == abs($balanceAmountDebit)) {
												$balanceAmountCredit = 0; // 100-100=0
												array_push($creditUsers[$ic]['creditRecord'], array(
													$debitUsers[$id]['id'] => abs($balanceAmountDebit)
												));
												$creditUsers[$ic]['creditMsg'] = $creditUsers[$ic]['creditMsg'] . ' ' . $debitUsers[$id]['name'] . ' will pay ' . $creditUsers[$ic]['name'] . ' Rs. ' . abs($balanceAmountDebit) . ';';
												array_push($debitUsers[$id]['debitRecord'], array(
													$creditUsers[$ic]['id'] => abs($balanceAmountDebit)
												));
												$debitUsers[$id]['debitMsg'] = $debitUsers[$id]['debitMsg'] . ' ' . $creditUsers[$ic]['name'] . ' will receive Rs. ' . abs($balanceAmountDebit) . ' from ' . $debitUsers[$id]['name'] . ';';
												$debitUsers[$id]['balAmount'] = 0;
												$creditUsers[$ic]['balAmount'] = 0;
											}
										} else {
											//Make this credit user's balance amount to 0 because now its bal is cleared
											$creditUsers[$ic]['balAmount'] = 0;
										}
									}
								}
								//5. Calculate credit/debit record per user:end
								//6. Update Credit & Debit Record all over
								$updateCreditDebitRecords = $this->team_model->updateCreditDebit($creditUsers, $debitUsers);
								if ($updateCreditDebitRecords) {
									$this->session->set_flashdata("success", "Expense added successfully");
									redirect('expense');
								} else {
									$this->session->set_flashdata("error", "Error while adding expense. Try again later");
									redirect('expense');
								}
							} else {
								$this->session->set_flashdata("error", "Error while adding expense");
								redirect('expense');
							}
						}
					} else {
						$this->session->set_flashdata("error", "Error while adding expense");
						redirect('expense');
					}
				} else {
					$this->session->set_flashdata("error", "Error while adding.");
					redirect('expense');
				}
				//3. Update team table
			} else {
				//Cant' add expense because team member registered date should be less then expense date
				$this->session->set_flashdata("error", "Expense date should be greater then user's registered date");
				redirect('expense');
			}
		}
	}

	/* Function Name: updateExpense()
		*  Function Type: Declarative
		*  Function Parameters: POST Param
		*  Function Description: Function to update expense member
		*  Function Return: TRUE|FALSE
    */
	public function updateExpense()
	{
		$this->form_validation->set_rules('userId', 'User', 'trim|required');
		$this->form_validation->set_rules('expenseDate', 'Expense Date', 'trim|required');
		$this->form_validation->set_rules('expenseAmount', 'Expense Amount', 'trim|required');
		if ($this->form_validation->run() == false) {
			$data['title'] = "Laravel Assignment - Expense";
			$data['description'] = "";
			$data['keyword'] = "";
			$data['expense_list'] = $this->expense_model->fetchExpenseWithUser();
			$data['team_list'] = $this->team_model->fetchTeamList();
			$data['page'] = $this->load->view('site/expense', $data, TRUE);
			$this->load->view('layouts/main', $data, FALSE);
		} else {
			$id = $this->input->post('id', TRUE);
			$data['userId'] = $this->input->post('userId', TRUE);
			$data['expenseDate'] = $this->input->post('expenseDate', TRUE);
			$data['expenseAmount'] = $this->input->post('expenseAmount', TRUE);
			$expenseAmountOld = $this->input->post('expenseAmountOld', TRUE);
			//Check if expense date should greater then user's registered date
			$expenseCanAdd = $this->team_model->fetchMemberRegisteredDate($data['expenseDate']);
			if ($expenseCanAdd->teamCount > 0) {
				//1. Update record in expense table
				$updateid = $this->expense_model->updateExpenses($data, $id);
				$totalExpenseAmount = 0;
				if ($updateid > 0) {
					//2. Update new expense added with respect to user:
					$updateExpense = $this->team_model->updateExpensesOfMember(array(
						"expenseAmount" => $data['expenseAmount'],
						"userId" => $data['userId'],
						"expenseAmountOld" => $expenseAmountOld
					));
					if ($updateExpense) {
						//3. Fetch total sum of expense from team table
						$totalExpense = $this->team_model->fetchTotalExpense();
						if ($totalExpense) {
							$totalExpenseAmount = $totalExpense->totalExpense;
							//4.Divide total expense with number of team mate
							$amountToPayPerMember = $totalExpenseAmount / ($totalExpense->totalTeamMember);
							$updateAmountToBePaid = $this->team_model->updateAmountToPay(array(
								"amountToPayPerMember" => $amountToPayPerMember
							));
							if ($updateAmountToBePaid) {
								//5. Calculate credit/debit record per user:
								//5.1 Fetch all team members
								$allTeamMembers = $this->team_model->fetchTeamList();
								//5.2 Filter all credit and debit user's
								$creditUsers = array();
								$debitUsers = array();
								foreach ($allTeamMembers as $team) {
									if ($team->balanceAmount > 0) {
										array_push($creditUsers, array(
											"id" => $team->id,
											"name" => $team->firstName . ' ' . $team->lastName,
											"balAmount" => $team->balanceAmount,
											"creditRecord" => array(),
											"creditMsg" => ""
										));
									} else {
										array_push($debitUsers, array(
											"id" => $team->id,
											"name" => $team->firstName . ' ' . $team->lastName,
											"balAmount" => $team->balanceAmount,
											"debitRecord" => array(),
											"debitMsg" => ""
										));
									}
								}
								//CREDIT USER LOOP
								for ($ic = 0; $ic < count($creditUsers); $ic++) {
									$balanceAmountCredit = $creditUsers[$ic]['balAmount'];
									//DEBIT USER LOOP
									for ($id = 0; $id < count($debitUsers); $id++) {
										$balanceAmountDebit = $debitUsers[$id]['balAmount'];
										if ($balanceAmountCredit > 0 && abs($balanceAmountDebit) > 0) {
											//a. if credit user's bal amount greater then debit user's amount then deduct & end loop: i.e. 200 > 100
											if ($balanceAmountCredit > abs($balanceAmountDebit)) {
												$balanceAmountCredit = $balanceAmountCredit - abs($balanceAmountDebit);
												array_push($creditUsers[$ic]['creditRecord'], array(
													$debitUsers[$id]['id'] => abs($balanceAmountDebit)
												));
												$creditUsers[$ic]['creditMsg'] = $creditUsers[$ic]['creditMsg'] . ' ' . $debitUsers[$id]['name'] . ' will pay ' . $creditUsers[$ic]['name'] . ' Rs. ' . abs($balanceAmountDebit) . ';';
												array_push($debitUsers[$id]['debitRecord'], array(
													$creditUsers[$ic]['id'] => abs($balanceAmountDebit)
												));
												$debitUsers[$id]['debitMsg'] = $debitUsers[$id]['debitMsg'] . ' ' . $creditUsers[$ic]['name'] . ' will receive Rs. ' . abs($balanceAmountDebit) . ' from ' . $debitUsers[$id]['name'] . ';';
												$debitUsers[$id]['balAmount'] = 0;
											}
											//b. if credit user's bal amount less then debit user's amount then deduct. i.e 100<200
											else if ($balanceAmountCredit < abs($balanceAmountDebit)) {
												$debitUsers[$id]['balAmount'] = $balanceAmountCredit - abs($balanceAmountDebit); // 100-200=-100
												array_push($creditUsers[$ic]['creditRecord'], array(
													$debitUsers[$id]['id'] => $balanceAmountCredit
												));
												$creditUsers[$ic]['creditMsg'] = $creditUsers[$ic]['creditMsg'] . ' ' . $debitUsers[$id]['name'] . ' will pay ' . $creditUsers[$ic]['name'] . ' Rs. ' . abs($balanceAmountDebit) . ';';
												array_push($debitUsers[$id]['debitRecord'], array(
													$creditUsers[$ic]['id'] => $balanceAmountCredit
												));
												$debitUsers[$id]['debitMsg'] = $debitUsers[$id]['debitMsg'] . ' ' . $creditUsers[$ic]['name'] . ' will receive Rs. ' . abs($balanceAmountDebit) . ' from ' . $debitUsers[$id]['name'] . ';';
												$balanceAmountCredit = 0;
												$creditUsers[$ic]['balAmount'] = 0;
											}
											//c. if credit user's bal amount equal to debit user's amount then deduct & end loop
											else if ($balanceAmountCredit == abs($balanceAmountDebit)) {
												$balanceAmountCredit = 0; // 100-100=0
												array_push($creditUsers[$ic]['creditRecord'], array(
													$debitUsers[$id]['id'] => abs($balanceAmountDebit)
												));
												$creditUsers[$ic]['creditMsg'] = $creditUsers[$ic]['creditMsg'] . ' ' . $debitUsers[$id]['name'] . ' will pay ' . $creditUsers[$ic]['name'] . ' Rs. ' . abs($balanceAmountDebit) . ';';
												array_push($debitUsers[$id]['debitRecord'], array(
													$creditUsers[$ic]['id'] => abs($balanceAmountDebit)
												));
												$debitUsers[$id]['debitMsg'] = $debitUsers[$id]['debitMsg'] . ' ' . $creditUsers[$ic]['name'] . ' will receive Rs. ' . abs($balanceAmountDebit) . ' from ' . $debitUsers[$id]['name'] . ';';
												$debitUsers[$id]['balAmount'] = 0;
												$creditUsers[$ic]['balAmount'] = 0;
											}
										} else {
											//Make this credit user's balance amount to 0 because now its bal is cleared
											$creditUsers[$ic]['balAmount'] = 0;
										}
									}
								}
								//5. Calculate credit/debit record per user:end
								//6. Update Credit & Debit Record all over
								$updateCreditDebitRecords = $this->team_model->updateCreditDebit($creditUsers, $debitUsers);
								if ($updateCreditDebitRecords) {
									$this->session->set_flashdata("success", "Expense update successfully");
									redirect('expense');
								} else {
									$this->session->set_flashdata("error", "Error while updating expense. Try again later");
									redirect('expense');
								}
							} else {
								$this->session->set_flashdata("error", "Error while updating expense");
								redirect('expense');
							}
						}
					} else {
						$this->session->set_flashdata("error", "Error while updating expense");
						redirect('expense');
					}
				} else {
					$this->session->set_flashdata("error", "Error while updating.");
					redirect('expense');
				}
				//3. Update team table
			} else {
				//Cant' add expense because team member registered date should be less then expense date
				$this->session->set_flashdata("error", "Expense date should be greater then user's registered date");
				redirect('expense');
			}
		}
	}
}

<div class="container" style="margin: 2em auto">
  <div class="row">
    <div class="col-lg-6">
      <h1>Team</h1>
    </div>
    <div class="col-lg-6" style="text-align: right">
      <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#team" aria-expanded="false" aria-controls="collapseExample">
        Add Teammate
      </button>
    </div>
  </div>
  <div class="collapse" id="team" style="margin-top: 1em">
    <div class="card card-body">
      <?php
      if (@validation_errors()) {
      ?>
        <div class="alert alert-danger">
          <h4>Oh snap! You got an error!</h4>
          <p><?php echo validation_errors(); ?></p>
        </div>
      <?php
      }
      ?>
      <?php echo form_open(base_url() . 'addTeamMember', array('name' => 'addTeamMemberForm')); ?>
      <div class="row">
        <div class="col-lg-3">
          <div class="form-group">
            <label for="exampleInputEmail1">First Name</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="firstName" />
          </div>
        </div>
        <div class="col-lg-3">
          <div class="form-group">
            <label for="exampleInputPassword1">Last Name</label>
            <input type="text" class="form-control" id="exampleInputPassword1" name="lastName" />
          </div>
        </div>
        <div class="col-lg-3">
          <div class="form-group">
            <label for="exampleInputPassword1">Email</label>
            <input type="email" class="form-control" id="exampleInputPassword1" name="email" />
          </div>
        </div>
        <div class="col-lg-3">
          <label for="exampleInputPassword1">&nbsp;</label>
          <button type="submit" class="btn btn-primary btn-block">Add</button>
        </div>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>



<div class="container">
  <div class="row">
    <div class="col-lg-12">
      <div class="list-group">
        <?php
        if ($team_list && count($team_list)) {
          foreach ($team_list as $team) {
        ?>

            <a href="javascript:void(0)" class="list-group-item list-group-item-action flex-column align-items-start">
              <div class="d-flex w-100 justify-content-between">
                <h5 class="mb-1"><?php echo ($team->firstName) ? $team->firstName . ' ' . $team->lastName : '-'; ?></h5>
                <small>last expense: <?php
                                      if ($team->lastExpenseDate) {
                                        $today = date('Y-m-d');
                                        $lastexpensedata = date("Y-m-d", strtotime($team->lastExpenseDate));
                                        $date1 = new DateTime($today);
                                        $date2 = new DateTime($lastexpensedata);
                                        $interval = $date1->diff($date2);
                                        if ($interval->d == 0) {
                                          echo 'Today';
                                        } else {
                                          echo $interval->d . ' days ago';
                                        }
                                      } else {
                                        echo "No expense yet!";
                                      }
                                      ?></small>
              </div>
              <small>
                <?php
                if ($team->balanceAmount < 0) {
                  echo $team->firstName." has to pay " . abs($team->balanceAmount);
                } else if ($team->balanceAmount > 0) {
                  echo $team->firstName." should receive " . abs($team->balanceAmount);
                }
                ?>
              </small>
              <button type="button" class="btn btn-light" data-toggle="modal" data-target="#teamEdit<?php echo $team->id; ?>">Edit</button>

            </a>
            <!-- Modal Start -->
            <div class="modal fade" id="teamEdit<?php echo $team->id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel<?php echo $team->id; ?>" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel<?php echo $team->id; ?>">Update Member Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <?php echo form_open(base_url() . 'editTeamMember', array('name' => 'editTeamMemberForm')); ?>
                  <input type="hidden" name="userid" value="<?php echo $team->id; ?>" />
                  <div class="modal-body">
                    <?php
                    if (@validation_errors()) {
                    ?>
                      <div class="alert alert-danger">
                        <h4>Oh snap! You got an error!</h4>
                        <p><?php echo validation_errors(); ?></p>
                      </div>
                    <?php
                    }
                    ?>

                    <div class="row">
                      <div class="col-lg-12">
                        <div class="form-group">
                          <label for="exampleInputEmail1">First Name</label>
                          <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="firstName" value="<?php echo $team->firstName; ?>" />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="form-group">
                          <label for="exampleInputPassword1">Last Name</label>
                          <input type="text" class="form-control" id="exampleInputPassword1" name="lastName" value="<?php echo $team->lastName; ?>" />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="form-group">
                          <label for="exampleInputPassword1">Email</label>
                          <input type="email" class="form-control" id="exampleInputPassword1" name="email" value="<?php echo $team->email; ?>" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                  </div>
                  <?php echo form_close(); ?>
                </div>
              </div>
            </div>
            <!-- Modal End -->
          <?php
          }
        } else {
          ?>
          No Team Member Added Yet!!
        <?php
        } ?>


      </div>
    </div>
  </div>
</div>
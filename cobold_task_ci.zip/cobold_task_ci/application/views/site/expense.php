<div class="container" style="margin:2em auto">
  <div class="row">
    <div class="col-lg-6">
      <h1>Team Expenses</h1>
    </div>
    <div class="col-lg-6" style="text-align: right">
      <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#expense" aria-expanded="false" aria-controls="collapseExample">
        Add an Expense
      </button>
    </div>
  </div>
  <div class="collapse" id="expense" style="margin-top: 1em">
    <div class="card card-body">
      <?php
      if (@validation_errors()) {
      ?>
        <div class="alert alert-danger">
          <h4>Oh snap! You got an error!</h4>
          <p><?php echo validation_errors(); ?></p>
        </div>
      <?php
      }
      ?>
      <?php echo form_open(base_url() . 'addExpense', array('name' => 'addExpenseForm')); ?>


      <div class="row">
        <div class="col-lg-3">
          <div class="form-group">
            <label for="exampleInputEmail1">Select User</label>
            <select class="form-control" name="userId">
              <option value="">Select Team Member</option>
              <?php if ($team_list && count($team_list)) {
                foreach ($team_list as $team) {
              ?>
                  <option value="<?php echo $team->id; ?>"><?php echo $team->firstName . ' (' . $team->email . ')'; ?></option>
              <?php }
              } ?>
            </select>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="form-group">
            <label>Expense Date</label>
            <input type="date" class="form-control" name="expenseDate" />
          </div>
        </div>
        <div class="col-lg-3">
          <div class="form-group">
            <label>Expense Amount</label>
            <input type="expenseAmount" class="form-control" placeholder="Amount" name="expenseAmount" />
          </div>
        </div>
        <div class="col-lg-3">
          <label for="exampleInputPassword1">&nbsp;</label>
          <button type="submit" class="btn btn-primary btn-block">Add an Expense</button>
        </div>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>
<div class="container">
  <table class="table table-hover">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Expense by</th>
        <th scope="col">Date</th>
        <th scope="col">Amount</th>
        <th scope="col">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
      if ($expense_list && count($expense_list)) {
        $i = 1;
        foreach ($expense_list as $expense) {
      ?>
          <tr>
            <th scope="row"><?php echo $i; ?></th>
            <td><?php echo $expense->firstName . ' ' . $expense->lastName; ?></td>
            <td><?php echo $expense->expenseDate; ?></td>
            <td>Rs. <?php echo $expense->expenseAmount; ?></td>
            <td><button type="button" class="btn btn-light" data-toggle="modal" data-target="#expenseEdit<?php echo $expense->id; ?>">Edit</button>
              <!-- Modal Start -->
              <div class="modal fade" id="expenseEdit<?php echo $expense->id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel<?php echo $expense->id; ?>" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel<?php echo $expense->id; ?>">Update Member Details</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <?php echo form_open(base_url() . 'editExpense', array('name' => 'eeditExpenseForm')); ?>
                    <input type="hidden" name="id" value="<?php echo $expense->id; ?>" />
                    <input type="hidden" name="userId" value="<?php echo $expense->userId; ?>" />
                    <div class="modal-body">
                      <?php
                      if (@validation_errors()) {
                      ?>
                        <div class="alert alert-danger">
                          <h4>Oh snap! You got an error!</h4>
                          <p><?php echo validation_errors(); ?></p>
                        </div>
                      <?php
                      }
                      ?>

                      <div class="row">
                        <div class="col-lg-12">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Select User</label>
                            <select class="form-control" value="userId" disabled="disabled">
                              <option value="">Select Team Member</option>
                              <?php if ($team_list && count($team_list)) {
                                foreach ($team_list as $team) {
                                  $selected="";
                                  if($expense->userId==$team->id){
                                    $selected="selected";
                                  }
                              ?>
                                  <option value="<?php echo $team->id; ?>" <?php echo $selected; ?>><?php echo $team->firstName . ' (' . $team->email . ')'; ?></option>
                              <?php }
                              } ?>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-12">
                          <div class="form-group">
                            <label>Expense Date</label>
                            <input type="date" class="form-control" name="expenseDate" value="<?php echo $expense->expenseDate; ?>"/>
                          </div>
                        </div>
                        <div class="col-lg-12">
                          <div class="form-group">
                            <label>Expense Amount</label>
                            <input type="hidden" name="expenseAmountOld" value="<?php echo $expense->expenseAmount; ?>"/>
                            <input type="text" class="form-control" placeholder="Amount" name="expenseAmount" value="<?php echo $expense->expenseAmount; ?>"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                    <?php echo form_close(); ?>
                  </div>
                </div>
              </div>
              <!-- Modal End -->
            </td>
          </tr>
      <?php
          $i++;
        }
      }else{
          ?>
          <tr>
          <td colspan="5">No expense yet!!</td></tr>
      <?php
      } ?>
    </tbody>
  </table>
</div>
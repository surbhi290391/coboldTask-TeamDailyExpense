<?php
class TeamModel extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    private static function tblPrifix()
    {
        return 'tbl_';
    }
    //Function to get record using id.
    public function getById($id)
    {
        $qryRes = $this->db->get_where(self::tblPrifix() . 'team', array('id' => $id));
        $res    = $qryRes->row();
        return $res;
    }
    //Function to get last expense date
    public function fetchLastExpenseDate($id)
    {
        $this->db->select("expenseDate as lastExpenseDate");
        $this->db->order_by("id", "desc");
        $this->db->limit(1);
        $qryRes = $this->db->get_where(self::tblPrifix() . 'expenses', array('userId' => $id));
        $res    = $qryRes->row();
        return $res;
    }

    //Add Record
    public function addTeam($data)
    {
        $this->db->insert(self::tblPrifix() . 'team', $data);
        return $this->db->insert_id();
    }

    //Update Record
    function updateTeam($data, $id)
    {
        $this->db->update(self::tblPrifix() . 'team', $data, array('id' => $id));
        return $id;
    }

    function updateTeamBalanceRecord($data)
    {
        foreach ($data['totalTeamMembers'] as $members) {
            //1.Add totalexpense amount of current user
            if ($members->id == $data['userId']) {
                $this->db->update(self::tblPrifix() . 'team', array(
                    "totalExpense" => $data['totalExpense']
                ), array('id' => $data['userId']));
            } else {
                //2. Fetch & recalculate Credit/Debit Record
            }
        }
        die;
    }

    function updateExpensesOfMember($data)
    {
        $expense = $data['expenseAmount'];
        if ($data['expenseAmountOld']) {
            $oldExp = $data['expenseAmountOld'];
            $this->db->query('UPDATE tbl_team set totalExpense=totalExpense-' . $oldExp . ' WHERE id=' . $data['userId']);
        }
        $this->db->query('UPDATE tbl_team set totalExpense=totalExpense+' . $expense . ' WHERE id=' . $data['userId']);
        return true;
    }
    function updateAmountToPay($data)
    {
        $payto = $data['amountToPayPerMember'];
        //$this->db->query('UPDATE tbl_team set amountToPayPerMember=amountToPayPerMember+'.$payto);
        $this->db->query('UPDATE tbl_team set amountToPayPerMember=' . $payto);
        if ($this->db->affected_rows()) {
            $this->db->query('UPDATE tbl_team set balanceAmount=totalExpense-amountToPayPerMember');
            return true;
        } else {
            return false;
        }
    }

    function updateCreditDebit($creditUsers, $debitUsers)
    {
        $this->db->query("UPDATE tbl_team set creditRecord='',debitRecord='',creditMsg='',debitMsg=''");
        if ($creditUsers && count($creditUsers)) {
            foreach ($creditUsers as $credit) {
                if (count($credit['creditRecord'])) {
                    $id = $credit['id'];
                    $creditRecords = json_encode($credit['creditRecord']);
                    $creditMsg = $credit['creditMsg'];
                    $this->db->query("UPDATE tbl_team set creditRecord='" . $creditRecords . "',creditMsg='" . $creditMsg . "' WHERE id=" . $id);
                }
            }
        }
        if ($debitUsers && count($debitUsers)) {
            foreach ($debitUsers as $debit) {
                if (count($debit['debitRecord'])) {
                    $id1 = $debit['id'];
                    $debitRecords = json_encode($debit['debitRecord']);
                    $debitMsg = $debit['debitMsg'];
                    $this->db->query("UPDATE tbl_team set debitRecord='" . $debitRecords . "',debitMsg='" . $debitMsg . "' WHERE id=" . $id1);
                }
            }
        }
        return true;
    }

    //Fetch fetchTotalExpense
    public function fetchTotalExpense()
    {
        $this->db->select("SUM(totalExpense) as totalExpense,COUNT(id) as totalTeamMember");
        $qryRes = $this->db->get_where(self::tblPrifix() . 'team', array());
        $res    = $qryRes->row();
        return $res;
    }

    //Fetch Records
    public function fetchTeamList()
    {
        $qryRes = $this->db->get_where(self::tblPrifix() . 'team', array('isDeleted' => 0));
        $res    = $qryRes->result();
        return $res;
    }

    //Fetch fetchMemberRegisteredDate
    public function fetchMemberRegisteredDate($date)
    {
        $this->db->select("count(id) as teamCount,DATE(createdDate) as createdDate");
        $this->db->where("DATE(createdDate)<=", $date);
        $qryRes = $this->db->get_where(self::tblPrifix() . 'team', array());
        $res    = $qryRes->row();
        return $res;
    }

    //Fetch Team member with their last expense.
    public function fetchTeamWithExpense()
    {
        $this->db->order_by("id", "desc");
        $this->db->select('t.*,e.expenseDate as lastExpenseDate');
        $this->db->from('tbl_team as t');
        $this->db->join('tbl_expenses as e', 't.id = e.userId', 'left');
        $this->db->where('t.isDeleted', 0);
        $query = $this->db->get();
        return $query->result();
    }

    //Fetch fetchTeamCount
    public function fetchTeamCount($date, $type)
    {
        $this->db->select("COUNT(id) as totalTeamMembers");
        if ($type == "yesterday") {
            $this->db->where("DATE(createdDate)<=", $date);
        } else if ($type == "today") {
            $this->db->where("DATE(createdDate)=", $date);
        }
        $qryRes = $this->db->get_where(self::tblPrifix() . 'team', array());
        $res    = $qryRes->row();
        return $res;
    }
}

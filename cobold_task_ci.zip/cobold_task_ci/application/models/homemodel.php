<?php
class HomeModel extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    private static function tblPrifix()
    {
        return 'tbl_';
    }

    //Fetch Team member with their expense.
    public function fetchTeamTransaction()
    {
        $query = $this->db->query('SELECT SUM(expenseAmount) as totalSpent, COUNT(id) as totalTransaction FROM `tbl_expenses` WHERE `expenseAmount` > 0 AND `expenseDate` BETWEEN CURDATE() - INTERVAL 30 DAY AND CURDATE()');
        $qryRes = $query->result_array();
        return $qryRes;
    }
    //Fetch Team member count for transaction
    public function fetchTeamMateCounter()
    {
        $query = $this->db->query('SELECT COUNT(id) as totalTeamMate FROM `tbl_expenses` WHERE `expenseAmount` > 0 GROUP BY userId');
        $qryRes = $query->result_array();
        return $qryRes;
    }

    //Fetch highest paid
    public function highestPaid()
    {
        $query = $this->db->query('SELECT MAX(totalExpense) as totalExpense, firstName, lastName FROM `tbl_team`');
        $qryRes = $query->result_array();
        return $qryRes;
    }
}

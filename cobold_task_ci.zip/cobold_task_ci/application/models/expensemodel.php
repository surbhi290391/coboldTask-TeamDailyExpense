<?php
class ExpenseModel extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    private static function tblPrifix()
    {
        return 'tbl_';
    }

    //Function to get record using id.
    public function getById($id)
    {
        $qryRes = $this->db->get_where(self::tblPrifix() . 'expenses', array('id' => $id));
        $res    = $qryRes->row();
        return $res;
    }

    //Add Record
    public function addExpense($data)
    {
        $this->db->insert(self::tblPrifix() . 'expenses', $data);
        return $this->db->insert_id();
    }

    //Update Record
    function updateExpenses($data, $id)
    {
        $this->db->update(self::tblPrifix() . 'expenses', $data, array('id' => $id));
        return $id;
    }

    //Fetch Records
    public function fetchExpense()
    {
        $qryRes = $this->db->get_where(self::tblPrifix() . 'expenses', array());
        $res    = $qryRes->result();
        return $res;
    }
    
    //Fetch fetchExpenseSUM
    public function fetchExpenseSUM($date, $type)
    {
        $this->db->select("SUM(expenseAmount) as totalExpenseAmount");
        if ($type == "yesterday") {
            $this->db->where("DATE(expenseDate)<=", $date);
        } else if ($type == "today") {
            $this->db->where("DATE(expenseDate)=", $date);
        }
        $qryRes = $this->db->get_where(self::tblPrifix() . 'expenses', array());
        $res    = $qryRes->row();
        return $res;
    }

    //Fetch expenses with member
    public function fetchExpenseWithUser()
    {
        $this->db->order_by("id","desc");
        $this->db->select('e.*,t.firstName,t.lastName,t.email');
        $this->db->from('tbl_expenses as e');
        $this->db->join('tbl_team as t', 'e.userId = t.id');
        $this->db->where('t.isDeleted', 0);
        $this->db->where('e.expenseAmount>', 0);
        $query = $this->db->get();
        return $query->result();
    }
}

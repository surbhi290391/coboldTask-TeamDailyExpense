# coboldTask-TeamDailyExpense
Team daily expenses
## Setup
